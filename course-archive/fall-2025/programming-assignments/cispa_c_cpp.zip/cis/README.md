# Computer Integrated Surgery (CIS) Programming Assignments

This repository contains the base structure for CIS Programming Assignments 1 & 2.

## Assignments

- **PA1**: Basic transformations & pivot calibration
- **PA2**: Distortion calibration & application

## Quick Start

1. Build the project:
   ```bash
   mkdir build && cd build
   cmake .. && make
   ```

2. Run a subroutine:
   ```bash
   ./cisHW1-2 --subroutine pa1_basic_transformations --input pa1-debug
   ```

See [USAGE.md](USAGE.md) for detailed usage instructions.

## Project Structure

- `src/cisHW1-2.cpp` - Main executable with subroutine dispatcher
- `data/PA1-2/` - Test data for PA1 and PA2
- `include/` - Header files
- `doc/` - Documentation and references

## Dependencies

- CMake 3.0+
- Eigen3
- Boost (program_options)
- C++11 compatible compiler

See [INSTALL.md](INSTALL.md) for detailed installation instructions.

## Support

For questions about the C++ structure or implementation, please reach out to:
- **Bohua Wan**
- **Kishore Paranthaman**
